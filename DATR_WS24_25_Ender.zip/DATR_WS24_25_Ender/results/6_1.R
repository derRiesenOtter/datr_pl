[1] "Report results of gffread"
[1] "Number of reference Transcripts generated:"
[1] 11599
[1] "Number of mRNA sequences:"
[1] 11599
[1] "All Transcripts have been translated. Transcribable elements are:"
[1] "mRNA"                      "tRNA"                     
[3] "snoRNA"                    "rRNA"                     
[5] "snRNA"                     "ncRNA"                    
[7] "telomerase_RNA"            "transposable_element_gene"
[1] "The reference.gff file contained 6585 genes."
[1] "Splice variants are responsible for the difference in transcripts and genes."
[1] "Of the 11599 transcribed elements in the gff, 2575 have only one splice variant, while 4512 have two."
