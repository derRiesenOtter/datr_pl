null device 
          1 
null device 
          1 
null device 
          1 
null device 
          1 
[1] "Top 3 Positive Genes:"
              logFC    logCPM          F       PValue          FDR
YNL115C   11.476795  2.531256   29.77250 8.011784e-04 3.297022e-03
YFL014W    9.123841 10.031925 1651.93006 7.534956e-12 2.475986e-08
YNCB0013W  7.992070 -1.063813   50.64891 1.373729e-04 8.590057e-04
[1] "Top 3 Negative Genes:"
               logFC    logCPM         F       PValue         FDR
YLR154W-C -19.833397 10.617226  7.427091 0.0281429625 0.056787089
YHR214C-C  -9.198394  3.432561 24.255214 0.0004995317 0.002325016
YDR365W-A  -7.844376  2.334898  2.098191 0.1886294510 0.270316780
[1] "Top 3 Positive Genes:"
              logFC     logCPM         F      PValue        FDR
YNL115C   10.019051  2.5312564 18.427514 0.003201593 0.01014018
YCL046W    7.446136 -0.2818672  7.992852 0.020127423 0.04415134
YDR316W-B  6.215621  2.9647775 12.395640 0.006169861 0.01736545
[1] "Top 3 Negative Genes:"
              logFC     logCPM        F     PValue        FDR
YGL152C   -7.811624 -0.9581958 9.176884 0.01804167 0.04037108
YGL239C   -6.308340 -0.6904405 5.711496 0.04661608 0.08829193
YER152W-A -6.011328 -0.7358621 2.184817 0.18111165 0.26627870
null device 
          1 
null device 
          1 
null device 
          1 
null device 
          1 
null device 
          1 
[1] "Top 3 Positive Genes:"
             logFC  AveExpr         t      P.Value    adj.P.Val        B
YNCE0024W 15.13425 15.03024 149.26914 5.915685e-17 1.756315e-15 26.57862
YNCL0012C 14.49756 14.63063  47.78867 2.181298e-12 3.274439e-12 19.20745
YNCL0021C 14.49756 14.63063  47.78867 2.181298e-12 3.274439e-12 19.20745
                  sig   gene_id
YNCE0024W Significant YNCE0024W
YNCL0012C Significant YNCL0012C
YNCL0021C Significant YNCL0021C
[1] "Top 3 Negative Genes:"
              logFC   AveExpr          t      P.Value    adj.P.Val          B
YCR045C   -5.878282 -3.682633 -3.4884938 0.0065706066 0.0070157638 -2.6523559
YLR154W-C -5.878282 -0.142895 -0.3473587 0.7360983311 0.7401527282 -6.8210845
YGL214W   -5.878139 -3.431191 -5.8026544 0.0002332581 0.0002550702  0.7900487
                      sig   gene_id
YCR045C       Significant   YCR045C
YLR154W-C Not Significant YLR154W-C
YGL214W       Significant   YGL214W
[1] "Top 3 Positive Genes:"
             logFC  AveExpr        t      P.Value    adj.P.Val        B
YNCE0024W 14.82852 15.03024 146.3961 7.079683e-17 2.045731e-15 26.50935
YNCL0012C 14.13713 14.63063  47.0409 2.522353e-12 3.691960e-12 19.07342
YNCL0021C 14.13713 14.63063  47.0409 2.522353e-12 3.691960e-12 19.07342
                  sig   gene_id
YNCE0024W Significant YNCE0024W
YNCL0012C Significant YNCL0012C
YNCL0021C Significant YNCL0021C
[1] "Top 3 Negative Genes:"
              logFC   AveExpr         t      P.Value    adj.P.Val         B
YGL239C   -6.016946 -2.829730 -6.204961 0.0001409147 0.0001543228  1.310172
YGL152C   -6.016927 -3.146186 -4.225163 0.0020925050 0.0022299243 -1.478378
YER152W-A -6.016711 -3.751088 -3.485064 0.0066067490 0.0069694309 -2.657947
                  sig   gene_id
YGL239C   Significant   YGL239C
YGL152C   Significant   YGL152C
YER152W-A Significant YER152W-A
[1] "Jaccard similarity coefficient for up regulated genes in condition 1:"
[1] 0
[1] "Jaccard similarity coefficient for up regulated genes in condition 2:"
[1] 0
[1] "Jaccard similarity coefficient for down regulated genes in condition 1:"
[1] 0.4814815
[1] "Jaccard similarity coefficient for down regulated genes in condition 2:"
[1] 0.1764706
