#!/bin/bash

curl 'https://ftp.ebi.ac.uk/pub/databases/GO/goa/proteomes/71242.S_cerevisiae_ATCC_204508.goa' \
  >../material/go_annotations
